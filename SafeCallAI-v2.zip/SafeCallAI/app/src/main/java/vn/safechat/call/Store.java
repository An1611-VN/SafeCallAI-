package vn.safechat.call;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

/** Lưu cài đặt, danh sách chặn và số lần báo cáo ngay trên máy. */
final class Store {
    private final SharedPreferences sp;

    Store(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("safecall", Context.MODE_PRIVATE);
    }

    /** Chuẩn hóa số: bỏ khoảng trắng và ký tự lạ, đổi +84 / 0084 thành 0. Tên gửi dạng chữ giữ nguyên. */
    static String norm(String raw) {
        if (raw == null) return "";
        String t = raw.trim();
        if (t.matches(".*[A-Za-z].*")) return t;
        String s = t.replaceAll("[^+0-9]", "");
        if (s.startsWith("+84")) s = "0" + s.substring(3);
        else if (s.startsWith("0084")) s = "0" + s.substring(4);
        return s;
    }

    Set<String> blocked() { return new TreeSet<>(sp.getStringSet("blocked", new HashSet<String>())); }

    boolean isBlocked(String number) { return blocked().contains(norm(number)); }

    void block(String number) {
        String n = norm(number);
        if (n.isEmpty()) return;
        Set<String> s = blocked();
        s.add(n);
        sp.edit().putStringSet("blocked", s).apply();
    }

    void unblock(String number) {
        Set<String> s = blocked();
        s.remove(norm(number));
        sp.edit().putStringSet("blocked", s).apply();
    }

    int reports(String number) { return sp.getInt("rep_" + norm(number), 0); }

    void report(String number) {
        String n = norm(number);
        if (n.isEmpty()) return;
        sp.edit().putInt("rep_" + n, reports(n) + 1).apply();
    }

    boolean autoBlock() { return sp.getBoolean("autoBlock", true); }
    void setAutoBlock(boolean v) { sp.edit().putBoolean("autoBlock", v).apply(); }

    boolean silenceSuspicious() { return sp.getBoolean("silence", false); }
    void setSilenceSuspicious(boolean v) { sp.edit().putBoolean("silence", v).apply(); }

    boolean smsAlerts() { return sp.getBoolean("smsAlerts", true); }
    void setSmsAlerts(boolean v) { sp.edit().putBoolean("smsAlerts", v).apply(); }
}
