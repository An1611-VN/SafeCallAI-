package vn.safechat.call;

import android.net.Uri;
import android.telecom.Call;
import android.telecom.CallScreeningService;

/** Sàng lọc cuộc gọi đến trước khi đổ chuông: số trong danh bạ luôn được phép. */
public class SpamCallScreeningService extends CallScreeningService {

    @Override
    public void onScreenCall(Call.Details details) {
        CallResponse.Builder resp = new CallResponse.Builder();
        try {
            if (details.getCallDirection() == Call.Details.DIRECTION_INCOMING) {
                Uri handle = details.getHandle();
                String num = handle == null ? "" : handle.getSchemeSpecificPart();
                Store st = new Store(this);
                NumberChecker.Info info = NumberChecker.check(this, num);

                if (info.name != null && info.level == TextAnalyzer.OK) {
                    // người quen: cho qua
                } else if (info.level == TextAnalyzer.BAD && st.autoBlock()) {
                    resp.setDisallowCall(true).setRejectCall(true);
                    Notifier.alert(this, "Đã chặn cuộc gọi nguy hiểm", info.display() + " · " + join(info));
                } else if (info.level >= TextAnalyzer.WARN && st.silenceSuspicious()) {
                    resp.setSilenceCall(true);
                    Notifier.alert(this, "Đã tắt tiếng cuộc gọi đáng ngờ", info.display() + " · " + join(info));
                }
            }
        } catch (Exception ignored) {
            resp = new CallResponse.Builder();   // lỗi: không chặn nhầm
        }
        respondToCall(details, resp.build());
    }

    private static String join(NumberChecker.Info i) {
        StringBuilder sb = new StringBuilder();
        for (String r : i.reasons) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(r);
        }
        return sb.toString();
    }
}
