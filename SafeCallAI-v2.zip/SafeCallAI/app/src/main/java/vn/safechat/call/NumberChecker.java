package vn.safechat.call;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.util.ArrayList;
import java.util.List;

/** Nhận diện người gọi: danh bạ, danh sách chặn, báo cáo của bạn và vài dấu hiệu bất thường. */
final class NumberChecker {

    static final class Info {
        String raw = "";
        String number = "";
        String name;                 // tên trong danh bạ, null nếu là số lạ
        int level = TextAnalyzer.OK;
        final List<String> reasons = new ArrayList<>();

        String display() {
            if (name != null) return name;
            return number.isEmpty() ? "Số ẩn" : number;
        }
    }

    static Info check(Context c, String raw) {
        Info i = new Info();
        i.raw = raw == null ? "" : raw;
        i.number = Store.norm(i.raw);
        Store st = new Store(c);

        if (i.number.isEmpty()) {
            i.level = TextAnalyzer.WARN;
            i.reasons.add("Người gọi ẩn số");
            return i;
        }
        i.name = contactName(c, i.raw);

        if (st.isBlocked(i.number)) {
            i.level = TextAnalyzer.BAD;
            i.reasons.add("Bạn đã chặn số này");
        }
        int rp = st.reports(i.number);
        if (rp > 0) {
            i.level = Math.max(i.level, rp >= 2 ? TextAnalyzer.BAD : TextAnalyzer.WARN);
            i.reasons.add("Bạn đã báo cáo số này " + rp + " lần");
        }
        if (i.name == null && i.number.startsWith("+")) {
            i.level = Math.max(i.level, TextAnalyzer.WARN);
            i.reasons.add("Số quốc tế không có trong danh bạ");
        }
        if (i.name != null) {
            i.reasons.add("Có trong danh bạ: " + i.name);
        } else if (i.reasons.isEmpty()) {
            i.reasons.add("Số lạ: chưa có trong danh bạ và chưa có báo cáo nào");
        }
        return i;
    }

    static String contactName(Context c, String number) {
        if (number == null || number.isEmpty()) return null;
        Cursor cur = null;
        try {
            Uri u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
            cur = c.getContentResolver().query(u,
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Exception ignored) {
            // chưa cấp quyền đọc danh bạ -> coi như số lạ
        } finally {
            if (cur != null) cur.close();
        }
        return null;
    }
}
