package vn.safechat.call;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.LinkedHashMap;
import java.util.Map;

/** Quét mọi tin nhắn SMS vừa đến và cảnh báo nếu có dấu hiệu lừa đảo. */
public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        if (!new Store(c).smsAlerts()) return;
        SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (parts == null) return;

        Map<String, StringBuilder> bySender = new LinkedHashMap<>();
        for (SmsMessage m : parts) {
            String from = m.getOriginatingAddress() == null ? "" : m.getOriginatingAddress();
            StringBuilder sb = bySender.get(from);
            if (sb == null) { sb = new StringBuilder(); bySender.put(from, sb); }
            sb.append(m.getMessageBody() == null ? "" : m.getMessageBody());
        }
        for (Map.Entry<String, StringBuilder> e : bySender.entrySet()) {
            TextAnalyzer.Result r = TextAnalyzer.analyze(e.getValue().toString());
            if (r.level == TextAnalyzer.OK) continue;
            StringBuilder why = new StringBuilder();
            for (TextAnalyzer.Hit h : r.hits) {
                if (why.length() > 0) why.append("; ");
                why.append(h.label);
            }
            NumberChecker.Info who = NumberChecker.check(c, e.getKey());
            String title = (r.level == TextAnalyzer.BAD ? "Tin nhắn nguy hiểm" : "Tin nhắn đáng ngờ")
                + " từ " + (who.name != null ? who.name : e.getKey()) + " (" + r.score + "/100)";
            Notifier.alert(c, title, why + ". " + TextAnalyzer.advice(r.level));
        }
    }
}
