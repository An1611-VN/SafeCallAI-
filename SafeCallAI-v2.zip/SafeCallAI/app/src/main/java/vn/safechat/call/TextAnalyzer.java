package vn.safechat.call;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bộ phân tích tín hiệu lừa đảo trong tin nhắn, chạy hoàn toàn trên máy.
 * Có lớp "giải mã" các thủ thuật né bộ lọc: chèn dấu chấm/gạch vào giữa chữ (ng.ân hà.ng),
 * cách chữ (O T P), thay chữ bằng số/ký hiệu (m4t kh@u), ký tự vô hình, chữ Cyrillic/Hy Lạp
 * giống chữ Latin, font lạ, và link viết dạng bit[.]ly. Cố tình né bộ lọc tự nó cũng là một tín hiệu.
 */
final class TextAnalyzer {
    static final int OK = 0, WARN = 1, BAD = 2;

    static final class Hit {
        final String label;
        final int weight;
        Hit(String label, int weight) { this.label = label; this.weight = weight; }
    }

    static final class Result {
        int score;
        int level;
        final List<Hit> hits = new ArrayList<>();
    }

    private static final String[] LABELS = {
        "Đòi mã OTP, mật khẩu hoặc mã bảo mật",
        "Yêu cầu cài ứng dụng hoặc tệp lạ",
        "Yêu cầu chuyển tiền, đặt cọc, nộp phí",
        "Mồi nhử tiền bạc (trúng thưởng, việc nhẹ lương cao)",
        "Đe dọa pháp lý hoặc khóa tài khoản",
        "Bắt giữ bí mật, cô lập người nhận",
        "Giả danh người thân (đổi số, gặp nạn)",
        "Giả mạo cơ quan hoặc tổ chức",
        "Gây áp lực thời gian",
        "Mời vay tiền, vay vốn nhanh"
    };
    private static final int[] WEIGHT = {35, 30, 25, 25, 20, 20, 20, 15, 15, 25};

    // Viết dấu cách bình thường; khi biên dịch mỗi dấu cách thành " ?" để bắt cả kiểu viết dính (nganhang, vayvon).
    private static final String[] RULE_SRC = {
        "(\\botp\\b|ma xac (thuc|nhan|minh)|mat khau|\\bcvv\\b|\\bpin\\b|ma bao mat)",
        "(\\.apk|cai (dat )?(ung dung|app)|tai (ung dung|app|file))",
        "(chuyen (khoan|tien|giup|cho)|nap tien|dat coc|nop phi|tai khoan an toan)",
        "(trung thuong|trung giai|nhan qua|qua tang|hoan (tien|thue)|viec nhe|luong cao|kiem tien|loi nhuan|lai suat cao|\\bdau tu\\b|nhiem vu)",
        "(bat giu|truy na|\\bkhoi to\\b|lenh bat|rua tien|vi pham phap luat|\\bbi phat\\b|bi khoa|tam khoa|khoa tai khoan|dinh chi)",
        "(khong (duoc )?(noi|tiet lo|cho (ai|nguoi))|khong (duoc )?bao (voi |cho )?(ai|nguoi)|bi mat|giu kin|dung (noi|bao|tiet lo) (voi |cho )?(ai|nguoi|ba|me|bo|gia dinh))",
        "(\\bdoi so\\b|so (dien thoai )?moi|dang o benh vien|\\btai nan\\b|\\bgap nan\\b)",
        "(cong an|canh sat|vien kiem sat|toa an|cuc thue|ngan hang|vietcombank|\\bvcb\\b|bidv|techcombank|agribank|\\bmb bank\\b|viettel|vnpt|buu dien|dien luc|\\bevn\\b|giao hang)",
        "(khan cap|ngay lap tuc|ngay bay gio|trong (vong )?\\d+ (gio|h|phut)|\\bhet han\\b|han chot|con \\d+ (gio|phut))",
        "(vay (von|tien|nhanh|tin chap|online|tai chinh)|cho vay|giai ngan|khong the chap|lai suat (thap|0)|duyet vay|ho tro vay)"
    };
    private static final Pattern[] RULE = new Pattern[RULE_SRC.length];
    static {
        for (int i = 0; i < RULE_SRC.length; i++) RULE[i] = Pattern.compile(RULE_SRC[i].replace(" ", " ?"));
    }

    private static final Pattern URL = Pattern.compile(
        "(?:https?://)?(?:(?:[a-z0-9-]+\\.)+(?:com|vn|net|org|xyz|top|vip|click|icu|cc|link|shop|online|site|buzz|cyou|info|me|ly|id|gl|co)"
        + "|\\d{1,3}(?:\\.\\d{1,3}){3})(?:/[^\\s]*)?", Pattern.CASE_INSENSITIVE);

    // ---- các mẫu để giải mã thủ thuật né bộ lọc
    private static final String INVIS_CLASS = "[\\u200B-\\u200F\\u202A-\\u202E\\u2060-\\u2064\\uFEFF\\u00AD\\u180E]";
    private static final Pattern INVIS = Pattern.compile(INVIS_CLASS);
    private static final Pattern INNER_INVIS = Pattern.compile("(?<=\\p{L})" + INVIS_CLASS + "+(?=\\p{L})");
    private static final Pattern INNER_PUNCT = Pattern.compile("(?<=\\p{L})[^\\p{L}\\p{N}\\s]+(?=\\p{L})");
    private static final Pattern STRIP_ASCII = Pattern.compile("(?<=[a-z0-9])[^a-z0-9\\s]+(?=[a-z0-9])");
    private static final Pattern SPACED_ASCII = Pattern.compile("(?<![a-z0-9])(?:[a-z] ){2,}[a-z](?![a-z0-9])");
    private static final Pattern SPACED_UNI = Pattern.compile("(?<![\\p{L}\\p{N}])(?:\\p{L} ){2,}\\p{L}(?![\\p{L}\\p{N}])");
    private static final Pattern LEET_INNER = Pattern.compile("[a-z][01345789@$!][a-z]");
    private static final Pattern LEET_INNER_UNI = Pattern.compile("(?<=\\p{L})[01345789@$!](?=\\p{L})");
    private static final Pattern TOKEN = Pattern.compile("\\S+");
    private static final Pattern DEFANG_DOT = Pattern.compile("(?i)\\s*[\\[({]\\s*(?:\\.|dot)\\s*[\\])}]\\s*");
    private static final Pattern DEFANG_HTTP = Pattern.compile("(?i)hxxp(s?)");

    // chữ giống chữ Latin: mỗi phần tử = ký tự giả + ký tự thật
    private static final String[] HOMO = {
        "\u0430a", "\u0435e", "\u043Eo", "\u0440p", "\u0441c", "\u0443y", "\u0445x", "\u0456i", "\u0458j",
        "\u0455s", "\u04BBh", "\u0501d", "\u051Bq", "\u051Dw", "\u0131i",
        "\u03B1a", "\u03BDv", "\u03BFo", "\u03C1p", "\u03B9i", "\u03B5e", "\u03C5u", "\u03BAk", "\u03F2c", "\u03C4t"
    };

    private static final int F_PUNCT = 1, F_LEET = 2, F_INVIS = 4, F_HOMO = 8, F_LINK = 16, F_SPACED = 32, F_FANCY = 64;

    // ------------------------------------------------------------------ chuẩn hóa

    private static String mapHomoglyphs(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            char out = c;
            for (String h : HOMO) { if (h.charAt(0) == c) { out = h.charAt(1); break; } }
            sb.append(out);
        }
        return sb.toString();
    }

    private static String lightNorm(String s) {
        String t = Normalizer.normalize(s, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        return mapHomoglyphs(INVIS.matcher(t).replaceAll(""));
    }

    /** Chữ thường, bỏ dấu tiếng Việt, bỏ ký tự vô hình, đổi chữ giả (Cyrillic/Hy Lạp/font lạ) về chữ Latin. */
    static String fold(String s) {
        String t = Normalizer.normalize(lightNorm(s), Normalizer.Form.NFD);
        return t.replaceAll("\\p{M}+", "").replace('đ', 'd');
    }

    private static String stripInner(String f) { return STRIP_ASCII.matcher(f).replaceAll(""); }

    private static String collapse(String f) {
        Matcher m = SPACED_ASCII.matcher(f);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(m.group().replace(" ", "")));
        m.appendTail(sb);
        return sb.toString();
    }

    private static char leetChar(char c) {
        switch (c) {
            case '0': return 'o'; case '1': return 'i'; case '3': return 'e'; case '4': return 'a';
            case '5': return 's'; case '7': return 't'; case '8': return 'b'; case '9': return 'g';
            case '@': return 'a'; case '$': return 's'; case '!': return 'i';
            default: return c;
        }
    }

    private static boolean isLetter(char c) { return c >= 'a' && c <= 'z'; }

    private static String leetToken(String tok) {
        if (tok.contains("/") || tok.contains(":") || tok.startsWith("www")) return tok;
        int letters = 0;
        for (int i = 0; i < tok.length(); i++) if (isLetter(tok.charAt(i))) letters++;
        if (letters < 1 || tok.matches("\\d+(k|tr|ty|d|h|g|m|p|phut|gio|ngay|vnd)?")) return tok;
        StringBuilder sb = new StringBuilder(tok.length());
        for (int i = 0; i < tok.length(); i++) {
            char c = tok.charAt(i);
            char mapped = leetChar(c);
            if (mapped == c) { sb.append(c); continue; }
            boolean prev = i > 0 && isLetter(tok.charAt(i - 1));
            boolean next = i < tok.length() - 1 && isLetter(tok.charAt(i + 1));
            boolean symbol = c == '@' || c == '$' || c == '!';
            sb.append((symbol ? (prev && next) : (prev || next)) ? mapped : c);
        }
        return sb.toString();
    }

    /** Đổi chữ-số-chữ (h4ng, m@t, kh0an) về chữ cái, giữ nguyên số tiền, giờ giấc. */
    private static String leet(String f) {
        Matcher m = TOKEN.matcher(f);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(leetToken(m.group())));
        m.appendTail(sb);
        return sb.toString();
    }

    private static String defang(String s) {
        String t = DEFANG_DOT.matcher(s).replaceAll(".");
        return DEFANG_HTTP.matcher(t).replaceAll("http$1");
    }

    // ------------------------------------------------------------------ nhận diện thủ thuật né lọc

    private static boolean urlish(String tok) {
        String low = tok.toLowerCase(Locale.ROOT);
        return low.contains("://") || low.contains("@") || low.startsWith("www.") || URL.matcher(tok).matches();
    }

    private static boolean mixedScript(String s) {
        boolean latin = false, other = false;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (!Character.isLetter(cp)) continue;
            Character.UnicodeScript sc = Character.UnicodeScript.of(cp);
            if (sc == Character.UnicodeScript.LATIN) latin = true;
            else if (sc == Character.UnicodeScript.CYRILLIC || sc == Character.UnicodeScript.GREEK) other = true;
        }
        return latin && other;
    }

    private static boolean fancy(String s) {
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if ((cp >= 0xFF21 && cp <= 0xFF3A) || (cp >= 0xFF41 && cp <= 0xFF5A)
                || (cp >= 0x1D400 && cp <= 0x1D7FF) || (cp >= 0x249C && cp <= 0x24E9)
                || (cp >= 0x1F130 && cp <= 0x1F189)) return true;
        }
        return false;
    }

    private static int tokenFlags(String tok) {
        if (urlish(tok)) return 0;
        String t = Normalizer.normalize(tok, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        int f = 0;
        if (fancy(tok)) f |= F_FANCY;
        if (INNER_INVIS.matcher(t).find()) f |= F_INVIS;
        String noInv = INVIS.matcher(t).replaceAll("");
        if (mixedScript(noInv)) f |= F_HOMO;
        if (!defang(tok).equals(tok)) f |= F_LINK;
        else if (INNER_PUNCT.matcher(noInv).find()) f |= F_PUNCT;
        if (LEET_INNER.matcher(fold(tok)).find()) f |= F_LEET;
        return f;
    }

    private static String trimEdges(String s) {
        return s.replaceAll("^[^\\p{L}\\p{N}]+|[^\\p{L}\\p{N}]+$", "");
    }

    /** Giải mã để hiển thị cho người dùng, vẫn giữ dấu tiếng Việt: ng.ân -> ngân. */
    private static String decodeKeep(String tok) {
        if (!defang(tok).equals(tok)) return trimEdges(defang(tok));
        String t = lightNorm(tok);
        t = INNER_PUNCT.matcher(t).replaceAll("");
        Matcher m = LEET_INNER_UNI.matcher(t);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, String.valueOf(leetChar(m.group().charAt(0))));
        m.appendTail(sb);
        return trimEdges(sb.toString());
    }

    private static String clip(String s) { return s.length() > 40 ? s.substring(0, 40) + "…" : s; }

    // ------------------------------------------------------------------ phân tích chính

    static Result analyze(String text) {
        Result r = new Result();
        if (text == null) text = "";

        String v0 = fold(text);                                   // bản sạch
        String v1 = collapse(stripInner(v0));                     // bỏ ký tự chèn giữa chữ, ghép chữ cách nhau
        String v2 = collapse(stripInner(leet(v0)));               // thêm đổi số/ký hiệu thành chữ

        int s = 0;
        boolean otp = false, pay = false, auth = false, revealed = false;
        for (int i = 0; i < RULE.length; i++) {
            boolean clean = RULE[i].matcher(v0).find();
            boolean any = clean || RULE[i].matcher(v1).find() || RULE[i].matcher(v2).find();
            if (!any) continue;
            r.hits.add(new Hit(LABELS[i], WEIGHT[i]));
            s += WEIGHT[i];
            if (!clean) revealed = true;                          // từ khóa chỉ lộ ra sau khi giải mã
            if (i == 0) otp = true;
            if (i == 2) pay = true;
            if (i == 7) auth = true;
        }

        // gom các từ bị bóp méo để báo cáo
        int kinds = 0;
        List<String> groups = new ArrayList<>();
        List<String> orig = new ArrayList<>(), dec = new ArrayList<>();
        Matcher tm = TOKEN.matcher(text);
        while (tm.find()) {
            String tok = tm.group();
            int f = tokenFlags(tok);
            if (f != 0 && !trimEdges(tok).isEmpty()) {
                kinds |= f;
                orig.add(trimEdges(tok));
                dec.add(decodeKeep(tok));
            } else if (!orig.isEmpty()) {
                groups.add("“" + clip(join(orig)) + "” → “" + clip(join(dec)) + "”");
                orig.clear(); dec.clear();
            }
        }
        if (!orig.isEmpty()) groups.add("“" + clip(join(orig)) + "” → “" + clip(join(dec)) + "”");

        Matcher sm = SPACED_UNI.matcher(lightNorm(text));
        while (sm.find()) {
            kinds |= F_SPACED;
            groups.add("“" + clip(sm.group()) + "” → “" + sm.group().replace(" ", "") + "”");
        }

        boolean strong = (kinds & (F_INVIS | F_HOMO | F_LINK | F_FANCY)) != 0 || revealed;
        if (strong || groups.size() >= 2) {
            StringBuilder ex = new StringBuilder();
            for (int i = 0; i < groups.size() && i < 3; i++) {
                if (i > 0) ex.append("; ");
                ex.append(groups.get(i));
            }
            if (ex.length() == 0) ex.append("từ khóa bị biến dạng (chèn ký tự, thay chữ bằng số...)");
            int w = strong ? 20 : 10;
            r.hits.add(new Hit((strong ? "Cố tình né bộ lọc: " : "Chữ bị chèn ký tự lạ: ") + ex, w));
            s += w;
        }

        // liên kết: phân tích trên bản đã gỡ kiểu bit[.]ly, hxxp
        String badHost = null;
        Matcher m = URL.matcher(defang(text));
        while (m.find()) {
            if (suspicious(m.group())) { badHost = host(m.group()); break; }
        }
        if (badHost != null) { r.hits.add(new Hit("Liên kết đáng ngờ: " + badHost, 30)); s += 30; }
        if (otp && auth) { r.hits.add(new Hit("Tổ hợp: giả danh kèm đòi mã xác thực", 10)); s += 10; }
        if (badHost != null && (otp || pay)) { r.hits.add(new Hit("Tổ hợp: liên kết lạ kèm yêu cầu tiền hoặc mã", 10)); s += 10; }

        r.score = Math.min(100, s);
        r.level = r.score < 25 ? OK : r.score < 55 ? WARN : BAD;
        return r;
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (String p : parts) { if (sb.length() > 0) sb.append(' '); sb.append(p); }
        return sb.toString();
    }

    private static String host(String u) {
        String h = u.toLowerCase(Locale.ROOT).replaceAll("[.,;!?]+$", "").replaceFirst("^https?://", "");
        int i = h.indexOf('/');
        return i >= 0 ? h.substring(0, i) : h;
    }

    static boolean suspicious(String u) {
        String low = u.toLowerCase(Locale.ROOT);
        String h = host(u);
        return h.matches("(bit\\.ly|tinyurl\\.com|cutt\\.ly|s\\.id|t\\.ly|rb\\.gy|is\\.gd|ow\\.ly)")
            || h.matches(".*\\.(xyz|top|vip|click|icu|cc|link|shop|online|site|buzz|cyou)")
            || low.startsWith("http://")
            || h.matches("\\d+\\.\\d+\\.\\d+\\.\\d+.*")
            || (h.matches(".*(vcb|vietcombank|bidv|techcombank|agribank|mbbank|momo|zalopay|viettel|vnpost|gov|police).*") && h.contains("-"));
    }

    static String label(int level) {
        return level == BAD ? "Nguy hiểm" : level == WARN ? "Nghi ngờ" : "An toàn";
    }

    static String advice(int level) {
        if (level == BAD) return "Không bấm liên kết, không chuyển tiền, không đọc mã OTP hay mật khẩu. Hãy gọi trực tiếp tổng đài chính thức của tổ chức để kiểm tra.";
        if (level == WARN) return "Hãy xác minh người gửi qua một kênh khác trước khi làm theo hoặc bấm liên kết.";
        return "Chưa thấy dấu hiệu lừa đảo rõ ràng. Vẫn nên cẩn thận với người lạ.";
    }
}
