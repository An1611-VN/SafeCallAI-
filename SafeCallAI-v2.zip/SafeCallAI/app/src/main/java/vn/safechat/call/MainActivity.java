package vn.safechat.call;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.Telephony;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int NEUTRAL = -1;
    private static final int C_PRI = 0xFF0E6B68, C_BG = 0xFFEEF2F4, C_TX = 0xFF12262B, C_MU = 0xFF617078,
        C_OK = 0xFF18794E, C_WA = 0xFF955A00, C_BAD = 0xFFB3261E;
    private static final String[] TAB_NAMES = {"Cuộc gọi", "Tin nhắn", "Tra cứu", "Cài đặt"};
    private static final String[] TAB_ICONS = {"📞", "💬", "🔍", "⚙️"};

    private Store store;
    private FrameLayout content;
    private final TextView[] tabViews = new TextView[4];
    private int tab = 0;

    private static final class Row {
        String title = "", sub = "", number = "", body = "", badge;
        int level, badgeLevel, score;
        final List<String> reasons = new ArrayList<>();
    }

    // ---------------------------------------------------------------- vòng đời

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);

        LinearLayout root = vbox();
        root.setBackgroundColor(C_BG);

        TextView head = tv("🛡️  SafeCall AI", 18, Color.WHITE, true);
        head.setBackgroundColor(C_PRI);
        head.setPadding(dp(16), dp(14), dp(16), dp(14));
        root.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setBackgroundColor(Color.WHITE);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = tv(TAB_ICONS[i] + "\n" + TAB_NAMES[i], 12, C_MU, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(8), 0, dp(8));
            t.setOnClickListener(v -> { tab = idx; show(); });
            tabViews[i] = t;
            nav.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        root.addView(nav, new LinearLayout.LayoutParams(MATCH, WRAP));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tab != 2 || content.getChildCount() == 0) show();   // giữ nội dung đang gõ ở tab Tra cứu
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        show();
    }

    private void show() {
        for (int i = 0; i < 4; i++) {
            tabViews[i].setTextColor(i == tab ? C_PRI : C_MU);
            tabViews[i].setTypeface(i == tab ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
        View v = tab == 0 ? callsView() : tab == 1 ? smsView() : tab == 2 ? lookupView() : settingsView();
        content.removeAllViews();
        content.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    // ---------------------------------------------------------------- tab Cuộc gọi

    private View callsView() {
        if (!has(Manifest.permission.READ_CALL_LOG)) {
            return permView("Cấp quyền đọc nhật ký cuộc gọi để SafeCall AI nhận diện số lạ và số nguy hiểm trong lịch sử cuộc gọi.");
        }
        List<Row> rows = new ArrayList<>();
        Map<String, NumberChecker.Info> cache = new HashMap<>();
        int risky = 0;
        Cursor c = null;
        try {
            c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE},
                null, null, CallLog.Calls.DATE + " DESC");
            int n = 0;
            while (c != null && c.moveToNext() && n++ < 150) {
                String num = c.getString(0) == null ? "" : c.getString(0);
                NumberChecker.Info i = cache.get(num);
                if (i == null) { i = NumberChecker.check(this, num); cache.put(num, i); }
                Row r = new Row();
                r.number = num;
                r.title = i.display();
                r.level = i.level;
                r.sub = (i.name != null ? i.number + " · " : "") + callType(c.getInt(2)) + " · "
                    + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(c.getLong(1)));
                if (i.level >= TextAnalyzer.WARN) {
                    r.badge = TextAnalyzer.label(i.level);
                    r.badgeLevel = i.level;
                    risky++;
                } else if (i.name == null) {
                    r.badge = "Số lạ";
                    r.badgeLevel = NEUTRAL;
                }
                rows.add(r);
            }
        } catch (Exception e) {
            toast("Không đọc được nhật ký cuộc gọi");
        } finally {
            if (c != null) c.close();
        }
        return listScreen("Đã kiểm tra " + rows.size() + " cuộc gọi · " + risky + " cuộc gọi đáng ngờ", rows, false);
    }

    private String callType(int t) {
        switch (t) {
            case CallLog.Calls.INCOMING_TYPE: return "Đến";
            case CallLog.Calls.OUTGOING_TYPE: return "Đi";
            case CallLog.Calls.MISSED_TYPE: return "Nhỡ";
            case CallLog.Calls.REJECTED_TYPE: return "Từ chối";
            case CallLog.Calls.BLOCKED_TYPE: return "Đã chặn";
            default: return "Khác";
        }
    }

    private void showNumberDialog(final String number) {
        NumberChecker.Info i = NumberChecker.check(this, number);
        StringBuilder sb = new StringBuilder(TextAnalyzer.label(i.level)).append("\n\n");
        for (String r : i.reasons) sb.append("• ").append(r).append('\n');
        AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle(i.display()).setMessage(sb.toString())
            .setNegativeButton("Đóng", null);
        if (!i.number.isEmpty()) {
            final boolean blocked = store.isBlocked(number);
            d.setPositiveButton(blocked ? "Bỏ chặn" : "Chặn số", (x, w) -> {
                if (blocked) store.unblock(number); else store.block(number);
                toast(blocked ? "Đã bỏ chặn" : "Đã chặn số này");
                show();
            });
            d.setNeutralButton("Báo cáo lừa đảo", (x, w) -> {
                store.report(number);
                toast("Đã ghi nhận báo cáo");
                show();
            });
        }
        d.show();
    }

    // ---------------------------------------------------------------- tab Tin nhắn

    private View smsView() {
        if (!has(Manifest.permission.READ_SMS)) {
            return permView("Cấp quyền đọc tin nhắn để SafeCall AI quét hộp thư và cảnh báo tin lừa đảo.");
        }
        List<Row> rows = new ArrayList<>();
        Map<String, NumberChecker.Info> cache = new HashMap<>();
        int risky = 0;
        Cursor c = null;
        try {
            c = getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,
                new String[]{Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE},
                null, null, Telephony.Sms.DATE + " DESC");
            int n = 0;
            while (c != null && c.moveToNext() && n++ < 150) {
                String addr = c.getString(0) == null ? "" : c.getString(0);
                String body = c.getString(1) == null ? "" : c.getString(1);
                NumberChecker.Info who = cache.get(addr);
                if (who == null) { who = NumberChecker.check(this, addr); cache.put(addr, who); }
                TextAnalyzer.Result a = TextAnalyzer.analyze(body);
                Row r = new Row();
                r.number = addr;
                r.body = body;
                r.title = who.name != null ? who.name : addr;
                r.sub = body.replace('\n', ' ');
                r.level = a.level;
                r.score = a.score;
                for (TextAnalyzer.Hit h : a.hits) r.reasons.add(h.label);
                if (a.level >= TextAnalyzer.WARN) {
                    r.badge = TextAnalyzer.label(a.level);
                    r.badgeLevel = a.level;
                    risky++;
                }
                rows.add(r);
            }
        } catch (Exception e) {
            toast("Không đọc được tin nhắn");
        } finally {
            if (c != null) c.close();
        }
        return listScreen("Đã quét " + rows.size() + " tin · phát hiện " + risky + " tin đáng ngờ", rows, true);
    }

    private void showSmsDialog(final Row r) {
        StringBuilder sb = new StringBuilder(TextAnalyzer.label(r.level)).append(" · ").append(r.score).append("/100\n\n");
        if (r.reasons.isEmpty()) sb.append("Không thấy tín hiệu bất thường.\n");
        for (String x : r.reasons) sb.append("• ").append(x).append('\n');
        sb.append('\n').append(TextAnalyzer.advice(r.level)).append("\n\nNội dung:\n").append(r.body);
        AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle(r.title).setMessage(sb.toString())
            .setNegativeButton("Đóng", null);
        if (!Store.norm(r.number).isEmpty()) {
            d.setPositiveButton("Chặn người gửi", (x, w) -> { store.block(r.number); toast("Đã chặn người gửi"); });
            d.setNeutralButton("Báo cáo", (x, w) -> { store.report(r.number); toast("Đã ghi nhận báo cáo"); });
        }
        d.show();
    }

    // ---------------------------------------------------------------- tab Tra cứu

    private View lookupView() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = vbox();
        box.setPadding(dp(16), dp(16), dp(16), dp(24));
        sv.addView(box);

        box.addView(tv("Tra cứu số điện thoại", 18, C_TX, true));
        final EditText num = new EditText(this);
        num.setHint("Nhập số điện thoại");
        num.setInputType(InputType.TYPE_CLASS_PHONE);
        box.addView(num);
        final LinearLayout res1 = vbox();
        box.addView(btn("Tra cứu số", v -> renderNumber(res1, num.getText().toString().trim())), lpTop(8));
        box.addView(res1);

        box.addView(tv("Kiểm tra tin nhắn", 18, C_TX, true), lpTop(28));
        final EditText msg = new EditText(this);
        msg.setHint("Dán nội dung tin nhắn nghi ngờ");
        msg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        msg.setMinLines(4);
        msg.setGravity(Gravity.TOP);
        box.addView(msg);
        final LinearLayout res2 = vbox();
        box.addView(btn("Phân tích tin nhắn", v -> {
            res2.removeAllViews();
            String s = msg.getText().toString().trim();
            if (s.isEmpty()) return;
            TextAnalyzer.Result a = TextAnalyzer.analyze(s);
            List<String> why = new ArrayList<>();
            for (TextAnalyzer.Hit h : a.hits) why.add(h.label + "  +" + h.weight);
            if (why.isEmpty()) why.add("Không thấy tín hiệu bất thường.");
            res2.addView(resultCard(a.level, TextAnalyzer.label(a.level) + " · " + a.score + "/100", why,
                TextAnalyzer.advice(a.level), null), lpTop(12));
        }), lpTop(8));
        box.addView(res2);
        return sv;
    }

    private void renderNumber(final LinearLayout res, final String s) {
        res.removeAllViews();
        if (s.isEmpty()) return;
        NumberChecker.Info i = NumberChecker.check(this, s);
        String adv;
        if (i.level == TextAnalyzer.BAD) adv = "Không nghe máy, không cung cấp mã OTP hay thông tin cá nhân.";
        else if (i.level == TextAnalyzer.WARN) adv = "Nếu họ tự xưng là ngân hàng hoặc cơ quan chức năng, hãy cúp máy và gọi lại số chính thức.";
        else if (i.name != null) adv = "Số này có trong danh bạ của bạn.";
        else adv = "Chưa có cảnh báo nào, nhưng hãy cẩn thận với số lạ yêu cầu tiền hoặc mã OTP.";
        final boolean blocked = store.isBlocked(s);
        LinearLayout actions = new LinearLayout(this);
        actions.addView(btn(blocked ? "Bỏ chặn" : "Chặn số", v -> {
            if (blocked) store.unblock(s); else store.block(s);
            renderNumber(res, s);
        }));
        actions.addView(btn("Báo cáo lừa đảo", v -> {
            store.report(s);
            toast("Đã ghi nhận báo cáo");
            renderNumber(res, s);
        }));
        res.addView(resultCard(i.level, i.display() + " · " + TextAnalyzer.label(i.level), i.reasons, adv, actions), lpTop(12));
    }

    private View resultCard(int level, String head, List<String> lines, String advice, View actions) {
        int col = colorOf(level);
        LinearLayout card = vbox();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(14));
        g.setStroke(dp(2), col);
        card.setBackground(g);
        card.addView(tv(head, 17, col, true));
        for (String l : lines) card.addView(tv("• " + l, 14, C_TX, false), lpTop(4));
        card.addView(tv(advice, 14, C_MU, false), lpTop(10));
        if (actions != null) card.addView(actions, lpTop(6));
        return card;
    }

    // ---------------------------------------------------------------- tab Cài đặt

    private View settingsView() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = vbox();
        box.setPadding(dp(16), dp(16), dp(16), dp(24));
        sv.addView(box);

        box.addView(tv("Chặn cuộc gọi", 18, C_TX, true));
        box.addView(tv(roleHeld()
            ? "✅ SafeCall AI đang là ứng dụng sàng lọc cuộc gọi."
            : "⚠️ Chưa bật. Hãy đặt SafeCall AI làm ứng dụng sàng lọc cuộc gọi để chặn số nguy hiểm trước khi đổ chuông.",
            14, roleHeld() ? C_OK : C_WA, false), lpTop(6));
        box.addView(btn("Đặt làm ứng dụng sàng lọc cuộc gọi", v -> requestRole()), lpTop(8));

        Switch s1 = sw("Tự động chặn số nguy hiểm", store.autoBlock());
        s1.setOnCheckedChangeListener((b, on) -> store.setAutoBlock(on));
        box.addView(s1, lpTop(12));
        Switch s2 = sw("Tắt tiếng số đáng ngờ (số ẩn, số quốc tế lạ)", store.silenceSuspicious());
        s2.setOnCheckedChangeListener((b, on) -> store.setSilenceSuspicious(on));
        box.addView(s2, lpTop(8));

        box.addView(tv("Tin nhắn", 18, C_TX, true), lpTop(24));
        Switch s3 = sw("Cảnh báo khi có tin nhắn lừa đảo đến", store.smsAlerts());
        s3.setOnCheckedChangeListener((b, on) -> store.setSmsAlerts(on));
        box.addView(s3, lpTop(8));

        box.addView(tv("Dữ liệu & quyền", 18, C_TX, true), lpTop(24));
        box.addView(btn("Cấp quyền cần thiết", v -> askAll()), lpTop(8));
        box.addView(btn("Danh sách số đã chặn (" + store.blocked().size() + ")", v -> showBlocked()), lpTop(4));
        box.addView(tv("SafeCall AI không có quyền Internet: danh bạ, nhật ký cuộc gọi và tin nhắn chỉ được xử lý trên máy của bạn. "
            + "Mức độ nguy hiểm dựa trên danh bạ, danh sách chặn và báo cáo của chính bạn, cùng bộ phân tích nội dung tin nhắn. "
            + "Đây là công cụ hỗ trợ, không thay thế việc tự xác minh qua kênh chính thức.", 13, C_MU, false), lpTop(16));
        return sv;
    }

    private boolean roleHeld() {
        RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
        return rm != null && rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)
            && rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);
    }

    private void requestRole() {
        RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
        if (rm == null || !rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            toast("Máy này không hỗ trợ sàng lọc cuộc gọi");
            return;
        }
        if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) { toast("Đã bật"); return; }
        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 7);
    }

    private void showBlocked() {
        final List<String> items = new ArrayList<>(store.blocked());
        if (items.isEmpty()) { toast("Chưa chặn số nào"); return; }
        new AlertDialog.Builder(this).setTitle("Chạm vào số để bỏ chặn")
            .setItems(items.toArray(new String[0]), (d, w) -> {
                store.unblock(items.get(w));
                toast("Đã bỏ chặn");
                show();
            })
            .setNegativeButton("Đóng", null).show();
    }

    // ---------------------------------------------------------------- quyền

    private List<String> perms() {
        List<String> p = new ArrayList<>(Arrays.asList(Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS));
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        return p;
    }

    private void askAll() {
        List<String> need = new ArrayList<>();
        for (String p : perms()) if (!has(p)) need.add(p);
        if (need.isEmpty()) { toast("Đã cấp đủ quyền"); return; }
        requestPermissions(need.toArray(new String[0]), 1);
    }

    private boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    private View permView(String msg) {
        LinearLayout l = vbox();
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(28), dp(28), dp(28), dp(28));
        TextView t = tv(msg, 15, C_TX, false);
        t.setGravity(Gravity.CENTER);
        l.addView(t);
        l.addView(btn("Cấp quyền", v -> askAll()), lpTop(12));
        return l;
    }

    // ---------------------------------------------------------------- danh sách dùng chung

    private View listScreen(String summary, final List<Row> rows, final boolean sms) {
        LinearLayout box = vbox();
        TextView s = tv(summary, 13, C_MU, false);
        s.setPadding(dp(16), dp(10), dp(16), dp(10));
        box.addView(s);
        if (rows.isEmpty()) {
            TextView e = tv("Chưa có dữ liệu để hiển thị.", 15, C_MU, false);
            e.setPadding(dp(16), dp(24), dp(16), dp(24));
            box.addView(e);
            return box;
        }
        ListView lv = new ListView(this);
        lv.setDivider(new ColorDrawable(0xFFDDE4E8));
        lv.setDividerHeight(1);
        lv.setAdapter(new RowAdapter(rows));
        lv.setOnItemClickListener((p, v, pos, id) -> {
            Row r = rows.get(pos);
            if (sms) showSmsDialog(r); else showNumberDialog(r.number);
        });
        box.addView(lv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        return box;
    }

    private final class RowAdapter extends BaseAdapter {
        private final List<Row> rows;
        RowAdapter(List<Row> rows) { this.rows = rows; }
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int i) { return rows.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View convert, ViewGroup parent) {
            Row r = rows.get(i);
            LinearLayout l = new LinearLayout(MainActivity.this);
            l.setGravity(Gravity.CENTER_VERTICAL);
            l.setBackgroundColor(Color.WHITE);
            l.setPadding(dp(16), dp(12), dp(16), dp(12));

            String ini = r.title.isEmpty() ? "?" : r.title.substring(0, 1).toUpperCase(Locale.ROOT);
            TextView av = tv(ini, 18, Color.WHITE, true);
            av.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(r.level == TextAnalyzer.BAD ? C_BAD : r.level == TextAnalyzer.WARN ? C_WA : C_PRI);
            av.setBackground(g);
            l.addView(av, new LinearLayout.LayoutParams(dp(44), dp(44)));

            LinearLayout mid = vbox();
            mid.setPadding(dp(12), 0, dp(8), 0);
            TextView t = tv(r.title, 16, C_TX, true);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            TextView s = tv(r.sub, 13, C_MU, false);
            s.setSingleLine(true);
            s.setEllipsize(TextUtils.TruncateAt.END);
            mid.addView(t);
            mid.addView(s);
            l.addView(mid, new LinearLayout.LayoutParams(0, WRAP, 1f));

            if (r.badge != null) l.addView(badge(r.badge, r.badgeLevel));
            return l;
        }
    }

    // ---------------------------------------------------------------- tiện ích giao diện

    private int colorOf(int level) {
        return level == TextAnalyzer.BAD ? C_BAD : level == TextAnalyzer.WARN ? C_WA : level == NEUTRAL ? C_MU : C_OK;
    }

    private TextView badge(String text, int level) {
        int bg = level == TextAnalyzer.BAD ? 0xFFFDE9E7 : level == TextAnalyzer.WARN ? 0xFFFFF0D1
            : level == NEUTRAL ? 0xFFE4E8EB : 0xFFE3F4EA;
        TextView t = tv(text, 11, colorOf(level), true);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(20));
        g.setColor(bg);
        t.setBackground(g);
        t.setPadding(dp(9), dp(2), dp(9), dp(2));
        return t;
    }

    private Switch sw(String label, boolean on) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(15);
        s.setTextColor(C_TX);
        s.setChecked(on);
        return s;
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams lpTop(int dpTop) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(MATCH, WRAP);
        p.topMargin = dp(dpTop);
        return p;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
