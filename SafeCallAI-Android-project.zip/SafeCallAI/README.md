# SafeCall AI – ứng dụng nhận diện cuộc gọi và chặn lừa đảo (kiểu Truecaller, chạy offline)

## Tính năng
- **Nhận diện người gọi**: đối chiếu số với danh bạ, danh sách chặn và báo cáo của bạn; gắn nhãn Số lạ, Nghi ngờ, Nguy hiểm.
- **Chặn cuộc gọi trước khi đổ chuông** (CallScreeningService): tự chặn số nguy hiểm, tùy chọn tắt tiếng số ẩn / số quốc tế lạ. Số trong danh bạ luôn được cho qua.
- **Quét SMS đến bằng AI** (bộ phân tích tín hiệu lừa đảo tiếng Việt): thông báo ngay khi tin nhắn có dấu hiệu OTP, giả công an/ngân hàng, link lạ, đòi chuyển tiền...
- **Lịch sử cuộc gọi và hộp thư SMS** hiển thị kèm nhãn rủi ro; chạm vào để chặn hoặc báo cáo.
- **Tra cứu** số điện thoại hoặc dán một tin nhắn bất kỳ để kiểm tra.
- Không khai báo quyền INTERNET: dữ liệu không rời khỏi máy.

## Tạo APK mà không cần cài Android Studio (dùng GitHub Actions, miễn phí)
1. Tạo tài khoản tại github.com, chọn New repository (để Private cũng được).
2. Giải nén file zip. Trong repo, chọn Add file > Upload files, rồi kéo TOÀN BỘ nội dung bên trong thư mục SafeCallAI vào (nhớ cả thư mục .github), bấm Commit changes.
   Nếu không thấy thư mục .github sau khi tải lên: chọn Add file > Create new file, gõ tên `.github/workflows/build.yml` và dán nội dung file build.yml vào.
3. Mở tab Actions. Lần chạy "Build APK" mất khoảng 3-5 phút.
4. Bấm vào lần chạy đó, kéo xuống mục Artifacts và tải SafeCallAI-apk. Giải nén sẽ được SafeCallAI.apk, chép sang điện thoại và cài.
Nếu lần chạy báo lỗi đỏ, hãy chụp hoặc sao chép phần log lỗi để được sửa.

## Tạo file APK bằng Android Studio
1. Cài Android Studio bản mới, chọn File > Open và mở thư mục này.
2. Đợi Gradle Sync (lần đầu cần mạng để tải Gradle 8.7 và Android SDK 34).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   File ở `app/build/outputs/apk/debug/app-debug.apk`.
4. Cài lên điện thoại Android 10 trở lên, mở app, vào tab Cài đặt:
   - bấm **Cấp quyền cần thiết**;
   - bấm **Đặt làm ứng dụng sàng lọc cuộc gọi** và đồng ý.
   Nếu Android 13+ báo "Cài đặt bị hạn chế": Cài đặt > Ứng dụng > SafeCall AI > ⋮ > Cho phép cài đặt bị hạn chế, rồi cấp quyền lại.

## Giới hạn cần biết
- Truecaller mạnh nhờ cơ sở dữ liệu số điện thoại khổng lồ do cộng đồng đóng góp trên máy chủ. Bản này chưa có máy chủ nên chỉ biết những số bạn tự chặn hoặc báo cáo, chưa tự nhận ra số lừa đảo mới.
- Android không cho ứng dụng sàng lọc cuộc gọi vẽ thông tin lên màn hình cuộc gọi; app báo qua thông báo.
- Google Play hạn chế quyền đọc SMS và nhật ký cuộc gọi, nên bản này phù hợp để cài trực tiếp (sideload).
- Trọng số của bộ phân tích tin nhắn là giá trị khởi tạo, chưa hiệu chỉnh từ dữ liệu thật; có thể báo nhầm hoặc bỏ sót.
