package vn.safechat.call;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Bộ phân tích tín hiệu lừa đảo trong tin nhắn (tầng 1 của SafeChat AI), chạy hoàn toàn trên máy. */
final class TextAnalyzer {
    static final int OK = 0, WARN = 1, BAD = 2;

    static final class Hit {
        final String label;
        final int weight;
        Hit(String label, int weight) { this.label = label; this.weight = weight; }
    }

    static final class Result {
        int score;
        int level;
        final List<Hit> hits = new ArrayList<>();
    }

    private static final String[] LABELS = {
        "Đòi mã OTP, mật khẩu hoặc mã bảo mật",
        "Yêu cầu cài ứng dụng hoặc tệp lạ",
        "Yêu cầu chuyển tiền, đặt cọc, nộp phí",
        "Mồi nhử tiền bạc (trúng thưởng, việc nhẹ lương cao)",
        "Đe dọa pháp lý hoặc khóa tài khoản",
        "Bắt giữ bí mật, cô lập người nhận",
        "Giả danh người thân (đổi số, gặp nạn)",
        "Giả mạo cơ quan hoặc tổ chức",
        "Gây áp lực thời gian"
    };
    private static final int[] WEIGHT = {35, 30, 25, 25, 20, 20, 20, 15, 15};
    private static final Pattern[] RULE = {
        Pattern.compile("(\\botp\\b|ma xac (thuc|nhan|minh)|mat khau|\\bcvv\\b|\\bpin\\b|ma bao mat)"),
        Pattern.compile("(\\.apk|cai (dat )?(ung dung|app)|tai (ung dung|app|file))"),
        Pattern.compile("(chuyen (khoan|tien|giup|cho)|nap tien|dat coc|nop phi|tai khoan an toan)"),
        Pattern.compile("(trung thuong|trung giai|nhan qua|qua tang|hoan (tien|thue)|viec nhe|luong cao|kiem tien|loi nhuan|lai suat cao|dau tu|nhiem vu)"),
        Pattern.compile("(bat giu|truy na|khoi to|lenh bat|rua tien|vi pham phap luat|bi phat|bi khoa|tam khoa|khoa tai khoan|dinh chi)"),
        Pattern.compile("(khong (duoc )?(noi|bao|cho ai|tiet lo)|bi mat|giu kin|dung (noi|bao|tiet lo))"),
        Pattern.compile("(doi so|so (dien thoai )?moi|dang o benh vien|tai nan|gap nan)"),
        Pattern.compile("(cong an|canh sat|vien kiem sat|toa an|cuc thue|ngan hang|vietcombank|\\bvcb\\b|bidv|techcombank|agribank|\\bmb ?bank\\b|viettel|vnpt|buu dien|dien luc|\\bevn\\b|giao hang)"),
        Pattern.compile("(khan cap|ngay lap tuc|ngay bay gio|trong (vong )?\\d+ ?(gio|h|phut)|het han|han chot|con \\d+ ?(gio|phut))")
    };
    private static final Pattern URL = Pattern.compile(
        "(?:https?://)?(?:(?:[a-z0-9-]+\\.)+(?:com|vn|net|org|xyz|top|vip|click|icu|cc|link|shop|online|site|buzz|cyou|info|me|ly|id|gl|co)"
        + "|\\d{1,3}(?:\\.\\d{1,3}){3})(?:/[^\\s]*)?", Pattern.CASE_INSENSITIVE);

    /** Chữ thường, bỏ dấu tiếng Việt: khớp được cả tin có dấu lẫn không dấu. */
    static String norm(String s) {
        String t = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        return t.replaceAll("\\p{M}+", "").replace('đ', 'd');
    }

    private static String host(String u) {
        String h = u.toLowerCase(Locale.ROOT).replaceAll("[.,;!?]+$", "").replaceFirst("^https?://", "");
        int i = h.indexOf('/');
        return i >= 0 ? h.substring(0, i) : h;
    }

    static boolean suspicious(String u) {
        String low = u.toLowerCase(Locale.ROOT);
        String h = host(u);
        return h.matches("(bit\\.ly|tinyurl\\.com|cutt\\.ly|s\\.id|t\\.ly|rb\\.gy|is\\.gd|ow\\.ly)")
            || h.matches(".*\\.(xyz|top|vip|click|icu|cc|link|shop|online|site|buzz|cyou)")
            || low.startsWith("http://")
            || h.matches("\\d+\\.\\d+\\.\\d+\\.\\d+.*")
            || (h.matches(".*(vcb|vietcombank|bidv|techcombank|agribank|mbbank|momo|zalopay|viettel|vnpost|gov|police).*") && h.contains("-"));
    }

    static Result analyze(String text) {
        Result r = new Result();
        if (text == null) text = "";
        String n = norm(text);
        int s = 0;
        boolean otp = false, pay = false, auth = false;
        for (int i = 0; i < RULE.length; i++) {
            if (RULE[i].matcher(n).find()) {
                r.hits.add(new Hit(LABELS[i], WEIGHT[i]));
                s += WEIGHT[i];
                if (i == 0) otp = true;
                if (i == 2) pay = true;
                if (i == 7) auth = true;
            }
        }
        String badHost = null;
        Matcher m = URL.matcher(text);
        while (m.find()) {
            if (suspicious(m.group())) { badHost = host(m.group()); break; }
        }
        if (badHost != null) { r.hits.add(new Hit("Liên kết đáng ngờ: " + badHost, 30)); s += 30; }
        if (otp && auth) { r.hits.add(new Hit("Tổ hợp: giả danh kèm đòi mã xác thực", 10)); s += 10; }
        if (badHost != null && (otp || pay)) { r.hits.add(new Hit("Tổ hợp: liên kết lạ kèm yêu cầu tiền hoặc mã", 10)); s += 10; }
        r.score = Math.min(100, s);
        r.level = r.score < 25 ? OK : r.score < 55 ? WARN : BAD;
        return r;
    }

    static String label(int level) {
        return level == BAD ? "Nguy hiểm" : level == WARN ? "Nghi ngờ" : "An toàn";
    }

    static String advice(int level) {
        if (level == BAD) return "Không bấm liên kết, không chuyển tiền, không đọc mã OTP hay mật khẩu. Hãy gọi trực tiếp tổng đài chính thức của tổ chức để kiểm tra.";
        if (level == WARN) return "Hãy xác minh người gửi qua một kênh khác trước khi làm theo hoặc bấm liên kết.";
        return "Chưa thấy dấu hiệu lừa đảo rõ ràng. Vẫn nên cẩn thận với người lạ.";
    }
}
